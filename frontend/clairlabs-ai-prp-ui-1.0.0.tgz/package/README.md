# @clairlabs-ai/prp-ui — Clair Design System

The **company-wide, framework-agnostic design system** for Clairlabs. Build the visual identity once
here; every product — the Clinical Trials Platform, CRP, anything new, React or not — consumes it and
inherits the same colors, gradients, typography, spacing, glass surfaces, hover effects, and
light/dark theming **automatically**.

Derived from the company **Design System spec** + **Style Guide** — the signature
**Electric Cyan → Soft Indigo → Vibrant Purple** glassmorphism language. The canonical source of that
language lives in [`docs/design-source/`](docs/design-source/); everything in this repo derives from
it and is guarded to stay faithful to it.

> **Status:** the library is feature-complete and green (25 components, tokens for web + Flutter,
> all guardrails passing) but **pre-release** — version `0.0.0`, local-first, not yet published. See
> [Project status](#project-status).

## Contents

- [What it is](#what-it-is) · [Quick start](#quick-start) · [Consuming it per framework](#consuming-it-per-framework)
- [Flutter / native](#flutter--native-tokens-only) · [Repository layout](#repository-layout) · [Components](#components-25)
- [Theming & tokens](#theming--tokens) · [Develop](#develop) · [Guardrails](#guardrails-pnpm-test)
- [Documentation](#documentation) · [Automation: the `.claude/skills` catalog](#automation-the-claudeskills-catalog)
- [Private hosting & install](#private-hosting--install) · [Project status](#project-status)

---

## What it is

`@clairlabs-ai/prp-ui` is **not an application** — it is the single source of truth for how Clairlabs
products look. It is built in three framework-neutral layers so any stack can consume it:

1. **Tokens** (`src/theme/`) — the design values (color, gradient, type, spacing, radius, shadow,
   motion) authored as [DTCG](https://tr.designtokens.org/) JSON and compiled by **Style Dictionary**
   to CSS variables (`--cds-*`), JavaScript, and Dart.
2. **CSS primitives** (`src/styles/` + each component's `.css`) — the `.cds-*` classes that own every
   visual decision. This layer is what makes two frameworks render pixel-identically.
3. **Framework bindings** (`src/components/`) — thin React wrappers that attach the `.cds-*` classes
   and wire behavior + accessibility. **They make no visual decisions** (no hex, no px sizing, no
   gradients in `.tsx` — every visual value is a token or a class).

**The layering law:** the tokens + CSS core is the universal substrate; bindings are thin. That is
what lets React today, Vue/Angular/Svelte tomorrow, and Flutter (tokens-only) all share one identity.

## Quick start

```bash
pnpm add @clairlabs-ai/prp-ui
```

```tsx
import '@clairlabs-ai/prp-ui/styles.css'; // the whole design system: tokens + reset + component styles
import { Button, Card, Input } from '@clairlabs-ai/prp-ui';

export function NewTrialCard() {
  return (
    <Card>
      <Input label="Trial protocol ID" placeholder="cardiac-study-04" />
      <Button variant="gradient">New Trial</Button>
    </Card>
  );
}
```

Light / dark is a single attribute on `<html>` (`dark` is the default); every component re-themes
with no extra work:

```html
<html data-mode="light"> … </html>
```

## Consuming it per framework

The design language lives in the two framework-neutral layers (**tokens** + **`.cds-*` CSS**), and
every web framework shares that same CSS — so they render pixel-identically. Only the thin binding
differs.

| Stack | What you get | How |
| :-- | :-- | :-- |
| **React** | React components **and** the CSS | `import { Button } from '@clairlabs-ai/prp-ui'` + `import '@clairlabs-ai/prp-ui/styles.css'` |
| **Next.js** (App Router) | Same as React | Import `styles.css` **once** in root `app/layout.tsx`; set `data-mode` on `<html>`. The package is `'use client'`-marked. |
| **Vue / Angular / Svelte / plain HTML** | The **CSS + tokens + `.cds-*` classes** (no components yet) | Import `styles.css`, apply `.cds-btn`, `.cds-card`, … to your markup |
| **Flutter / native** | **Tokens only** (as a Dart file) | See [below](#flutter--native-tokens-only) |

Three entry points back this:

- `@clairlabs-ai/prp-ui` — React components (JS + types)
- `@clairlabs-ai/prp-ui/styles.css` — **everything**: tokens + reset + all component CSS
- `@clairlabs-ai/prp-ui/theme.css` — **tokens only** (`--cds-*` variables)

> **One rule for every consumer: consume, don't fork.** Never redefine `--cds-*` values or hand-roll
> the look in app code — that reintroduces the per-team drift the design system exists to prevent.
> Apps own *layout and content*; the library owns *look and feel*. If something visual is missing,
> it's a change in the library, not an app-level override.

## Flutter / native (tokens only)

Flutter **cannot** import the React components or the CSS (different runtime). It shares **only the
token values**: Style Dictionary emits the same `--cds-*` graph as a Dart file.

**Built ✅ — the Dart token target.** `pnpm build:tokens` emits
[`platforms/flutter/lib/src/clair_tokens.dart`](platforms/flutter/) (the `clair_tokens` package) with
**both themes**:

- `ClairTokens` — the dark theme (default)
- `ClairTokensLight` — the light theme (every token resolved with the `[data-mode="light"]` overrides)

Colors map to `Color`, dimensions to `double`, weights to `FontWeight`; composite web values
(gradients, shadows, blur, easing) are preserved as their source strings for native code to adapt. A
`check-token-parity` guard (in `pnpm test`) fails if either theme class ever drifts from the token
source. See [`platforms/flutter/README.md`](platforms/flutter/README.md).

**Not built (by design) — the native widget set.** Widgets (`ClairButton`, `ClairCard`, …) would be
a **separate, hand-written Flutter implementation** that reads those tokens. Parity is therefore
**token-level** (same colors, radii, spacing, type) — **not** pixel-identical: glass, the
gradient-border hover, and motion are re-created with Flutter-native techniques (`BackdropFilter`,
`ShaderMask`, …). This is intentionally **demand-driven** — stood up when a real mobile product needs
it, per the tokens-only contract ([`cross-framework-architecture.md`](docs/cross-framework-architecture.md) §8).

## Repository layout

One package. Tokens live in `theme/`; every component is a **self-contained folder** that owns its
markup, styles, variants, behavior, tests, and Storybook story.

```
src/
├─ theme/                     the visual language — single source of truth
│  ├─ tokens/*.json           DTCG tokens: color, gradient, type, spacing, radii, shadow — light + dark
│  └─ build-tokens.mjs        Style Dictionary → tokens.css + tokens.js + clair_tokens.dart (generated)
├─ styles/
│  ├─ reset.css               base reset + helpers (layered low, so a host app's resets win)
│  └─ styles.css              bundle entry: tokens + reset + every component's CSS
├─ components/<Name>/         one folder each: <Name>.tsx + .css + .test.tsx + .stories.tsx + index.ts
└─ index.ts                   barrel — exports every component

platforms/flutter/           the Dart token package (tokens-only)
scripts/                      guardrail scripts (token integrity, refs, css-ownership, api, parity, changelog)
docs/                         architecture, contracts, the canonical design source
.claude/                      skills + agents that build, review, and maintain the library (see below)
```

## Components (25)

**Inputs & controls:** `Button` · `Input` · `Textarea` · `Checkbox` · `Radio` (`RadioGroup`) ·
`Select` · `SegmentedControl`
**Surfaces & overlays:** `Card` · `Panel` · `Dialog` · `DropdownMenu` · `Tooltip`
**Feedback & status:** `Alert` · `Toast` · `Badge` · `Chip` · `Progress` · `Spinner` · `Skeleton`
**Navigation & structure:** `AppHeader` (+ `BrandIcon`) · `Tabs` · `Breadcrumb` · `Table` ·
`Avatar` · `EmptyState`

The interactive ones (Select, Dialog, Toast, Tabs, Tooltip, DropdownMenu, Checkbox, Radio,
SegmentedControl) use **Radix** under the hood — inside their own folder — for behavior and
accessibility, so from a consumer's side it's just `<Select>`. Components are **RTL-safe** (logical
CSS properties) and honor `prefers-reduced-motion`. Every component ships with a jest-axe
accessibility test.

## Theming & tokens

All colors / gradients / spacing / type / radii / shadows live **only** in
[`src/theme/tokens/*.json`](src/theme/tokens/) and flow everywhere through `--cds-*` CSS variables —
change a token and every component updates. Tokens follow a three-tier structure:

- `--cds-ref-*` — **reference** primitives (raw palette, the dimension scale)
- `--cds-sys-*` — **semantic** roles (text, surface, accent, status, elevation, motion) — mode-aware
- `--cds-comp-*` — **component** tokens (per-component recipes)

Light and dark are two value sets keyed off `data-mode` on the root element; there is zero
per-component theme code. See [`docs/token-architecture.md`](docs/token-architecture.md).

## Develop

```bash
pnpm install
pnpm build:tokens    # DTCG → tokens.css + tokens.js + clair_tokens.dart (dark + light)
pnpm storybook       # visual workshop at http://localhost:6006 (light/dark toggle, a11y checks)
pnpm build           # → dist/index.js + dist/styles.css + dist/theme.css
pnpm test            # full gate: build → guards → type-check → component tests
```

## Guardrails (`pnpm test`)

A design system's promise is consistency, so every change is machine-checked. `pnpm test` runs the
whole chain and is the definition of "done":

- **token integrity** — tokens are well-formed; no tier references "up" a level
- **layer integrity** (token-refs) — every `var(--cds-*)` a component uses is a real, defined token
- **css ownership** — the reset stays layered; components stay UNLAYERED so they out-rank a
  consumer's element resets (e.g. Tailwind Preflight) yet still yield to the consumer's own classes
- **token parity** — the Flutter Dart target emits every source token, in both theme classes
- **public-API snapshot** — any change to exported names / tokens / classes must be deliberate
- **changelog** — a rendered-value or public-surface change must be recorded in [`CHANGELOG.md`](CHANGELOG.md)
- **type-check** (`tsc`) + **component tests** (Vitest + Testing Library + jest-axe)

## Documentation

| Doc | What it covers |
| :-- | :-- |
| [`docs/design-source/`](docs/design-source/) | **The canonical design language** — `design-system.md` (spec) + `styleguide.html` (executable reference). The source of truth everything derives from. |
| [`docs/token-architecture.md`](docs/token-architecture.md) | The three token tiers and how the design source maps to `--cds-*` + the build pipeline (CSS / JS / Dart). |
| [`docs/component-contract.md`](docs/component-contract.md) | The primitive inventory: prop APIs, states, and accessibility requirements every component must satisfy. |
| [`docs/cross-framework-architecture.md`](docs/cross-framework-architecture.md) | Why React is one adapter, not the center; the layered foundation; the Flutter tokens-only boundary (§8). |
| [`docs/ADAPTER-CONTRACT.md`](docs/ADAPTER-CONTRACT.md) | What a framework binding may and may not do. |
| [`docs/VERSIONING.md`](docs/VERSIONING.md) | The public-API and release contract (an intentional visual change is at least a MINOR bump). |
| [`docs/adr/`](docs/adr/) | Architecture Decision Records (e.g. `0001` — why component styles are unlayered). |
| [`docs/V1-READINESS-PLAN.md`](docs/V1-READINESS-PLAN.md) | The sequenced plan from "spike" to "consumable"; note some milestones predate the current single-package rework. |
| [`CHANGELOG.md`](CHANGELOG.md) | Every rendered-value and public-surface change, `[visual]`-tagged. |

## Automation: the `.claude/skills` catalog

This repo ships **21 skills + 1 review agent** under [`.claude/skills/`](.claude/skills/) and
[`.claude/agents/`](.claude/agents/) — packaged workflows (for [Claude Code](https://claude.com/claude-code))
that build, review, and maintain the library while enforcing the layering law, design-source
fidelity, and the verify gate. They are the operational knowledge of *how this design system is
worked on*, captured as runnable procedures.

**Foundation (loaded by the others; not run directly)**

| Skill | Its job |
| :-- | :-- |
| `common-instructions` | Shared protocols every maintainer skill loads at startup: the design-source-reading rule, the framework-agnostic layering law, fidelity & deviation discipline, the `pnpm` verify protocol, contract checkpoints, and the changelog protocol. |
| `instruction-adherence-check` | Final quality gate — checks a skill's output against its own instructions and the design-system constraints before it's delivered. |

**Build the library**

| Skill | Its job |
| :-- | :-- |
| `create-component` | Add a primitive the right way: contract + CSS first, then the thin React binding, stories, tests, barrel, and public-API snapshot. |
| `add-token` | Add or change a tier-correct `--cds-ref/sys/comp` token in both modes, rebuild, and re-run the token guards. |
| `write-stories` | Author or expand a component's Storybook stories (states, variants, interaction tests). |
| `create-adapter` | Scaffold a new framework binding (Vue/Angular/Svelte) against the CSS/token core — handles the aspirational-vs-current package gap. |
| `create-adr` | Record an architecture decision in `docs/adr/` in the established format. |
| `ship-component` | End-to-end orchestrator: runs create-component → write-stories → a11y-audit → review-change → verify as one artifact, with a checkpoint gate per phase. |

**Review & verify**

| Skill | Its job |
| :-- | :-- |
| `investigate` | End-to-end health investigation: runs the whole gate **and** sweeps everything it doesn't (per-component completeness, orphan/phantom classes, layering-law literals, Storybook build, contract coverage, the Flutter target). Reports every issue with symptom, location, cause, and fix in `.claude/investigations/`. A superset of `verify`. |
| `verify` | Run the full guardrail suite in order and triage any failure to a root cause. `pnpm test` is the one-shot gate; this explains *why* it's red. |
| `design-fidelity-audit` | Audit the library against the design source and produce a severity-ranked drift report (DRIFT / GAP / NIT / SOURCE-ISSUE) in `.claude/audits/`. |
| `review-change` | Review a git diff against fidelity, the layering law, the component contract, a11y, and API impact → report in `.claude/reviews/`. |
| `a11y-audit` | Accessibility audit of components (roles, keyboard, focus, contrast, axe). |
| `architecture-consistency-check` | Check the repo against the cross-framework architecture and contracts. |
| `checkpoint-reviewer` *(agent)* | A fresh reviewer invoked at a skill's phase boundaries to verify that phase's work before the next begins. |

**Release**

| Skill | Its job |
| :-- | :-- |
| `release` | Drive the versioning/release flow — promote the `[Unreleased]` changelog, apply the visual-change-is-MINOR rule, and stage a publish. |

**Consumer-facing (run inside a product that consumes the library)**

| Skill | Its job |
| :-- | :-- |
| `integrate-library` | Onboard a consuming app (any framework) — wire up the CSS entry point, `data-mode`, and imports. |
| `use-component` | Use a DS component correctly in a consumer app (and swap out a hand-rolled equivalent). |
| `upgrade-library` | Upgrade a consumer to a new library version, surfacing rendered-value changes from the changelog. |

**Working sessions**

| Skill | Its job |
| :-- | :-- |
| `chat` | Conversational thinking-partner mode that reasons from the design source and contracts. |
| `compaction-create-handoff-note` | Write a handoff note (`.claude/handoff/`) so a fresh session can resume in-flight work cleanly. |
| `compaction-resume-work` | Read that handoff note and resume the paused work. |

> Only `.claude/skills/` and `.claude/agents/` are tracked in git; ephemeral run artifacts
> (`.claude/audits`, `reviews`, `handoff`) and local config are git-ignored.

## Private hosting & install

The library is hosted on a **private GitHub repo** and gated so installing requires authentication.
The *effect* is the same for both worlds; the *plumbing* differs.

**React / npm — GitHub Packages (token-gated).** Publish to GitHub's npm registry; consumers need a
GitHub token with `read:packages` in their `.npmrc`:

```
@clairlabs:registry=https://npm.pkg.github.com
//npm.pkg.github.com/:_authToken=${GITHUB_TOKEN}
```

Then `npm install @clairlabs-ai/prp-ui` fails without a valid token. (Today the package is distributed as a
local tarball — `clairlabs-ui-<version>.tgz` — until it's published; see the `release` skill.)

**Flutter — git dependency (git-auth-gated).** Dart/pub has no token registry like npm; instead depend
on the private repo as a **git dependency**, so the gate is your git credentials (SSH key or an HTTPS
PAT in git's credential store):

```yaml
dependencies:
  clair_tokens:
    git:
      url: git@github.com:Clairlabs-AI/PRP-C-FE-LIB.git
      path: platforms/flutter   # the Dart package lives in this subfolder
      ref: main
```

## Project status

**Done** — 25 components (the contract set is complete), design-fidelity audit **FAITHFUL**, RTL,
tokens for **web + Flutter (dark + light)**, the full guardrail suite green, and the `.claude`
automation. The library itself is feature-complete.

**Remaining (release / distribution — not yet started):** publish off `0.0.0` (versioning +
changesets), a first green CI run, a `ThemeProvider` / SSR no-flash helper, and a consumer-integration
test harness. **Demand-driven (no consumer yet):** Vue/Angular/Svelte bindings + the Flutter native
widget set. See [`docs/V1-READINESS-PLAN.md`](docs/V1-READINESS-PLAN.md).
